import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHeader } from "@/components/PageHeader";
import { getDashboard } from "@/lib/api";

function meter(value: number) {
  return `${Math.max(0, Math.min(100, value))}%`;
}

export default async function PetDashboardPage({ params }: { params: Promise<{ petId: string }> }) {
  const { petId } = await params;
  const dashboard = await getDashboard(Number(petId)).catch(() => null);

  if (!dashboard) notFound();

  const state = dashboard.virtual_pet_state;
  const record = dashboard.today_record;

  return (
    <main className="page stack">
      <PageHeader
        petId={dashboard.pet.id}
        title={`${dashboard.pet.name} 的主页`}
        subtitle="把真实养宠记录、虚拟成长状态和当日任务放在同一页。这个页面最适合做首屏演示。"
        active="dashboard"
      />

      <div className="grid grid-2">
        <section className="card stack">
          <div className="badge">真实宠物档案</div>
          <h2 className="section-title">{dashboard.pet.name}</h2>
          <dl className="kv">
            <div><dt>物种</dt><dd>{dashboard.pet.species}</dd></div>
            <div><dt>品种</dt><dd>{dashboard.pet.breed || "未填写"}</dd></div>
            <div><dt>体重</dt><dd>{dashboard.pet.weight_kg ?? "-"}</dd></div>
            <div><dt>性别</dt><dd>{dashboard.pet.gender || "未填写"}</dd></div>
            <div><dt>绝育</dt><dd>{dashboard.pet.neutered ? "是" : "否"}</dd></div>
          </dl>
          <div className="row">
            <Link className="button inline" href={`/pets/${petId}/records`}>去记今日记录</Link>
            <Link className="button inline secondary" href={`/pets/${petId}/assistant`}>打开 Agent</Link>
          </div>
        </section>

        <section className="card stack">
          <div className="badge">电子宠物状态</div>
          {state ? (
            <>
              <div className="grid grid-3">
                <div className="metric"><strong>Lv.{state.level}</strong><span>等级 · {state.growth_stage}</span></div>
                <div className="metric"><strong>{state.xp}</strong><span>当前 XP</span></div>
                <div className="metric"><strong>{state.coins}</strong><span>金币</span></div>
              </div>
              <div className="stack">
                <div>
                  <div className="row" style={{ justifyContent: "space-between" }}><span>Hunger</span><span>{state.hunger}</span></div>
                  <div className="progress"><span style={{ width: meter(100 - state.hunger) }} /></div>
                </div>
                <div>
                  <div className="row" style={{ justifyContent: "space-between" }}><span>Mood</span><span>{state.mood}</span></div>
                  <div className="progress"><span style={{ width: meter(state.mood) }} /></div>
                </div>
                <div>
                  <div className="row" style={{ justifyContent: "space-between" }}><span>Energy</span><span>{state.energy}</span></div>
                  <div className="progress"><span style={{ width: meter(state.energy) }} /></div>
                </div>
                <div>
                  <div className="row" style={{ justifyContent: "space-between" }}><span>Intimacy</span><span>{state.intimacy}</span></div>
                  <div className="progress"><span style={{ width: meter(state.intimacy) }} /></div>
                </div>
              </div>
            </>
          ) : <div className="empty">还没有电子宠物状态。</div>}
        </section>
      </div>

      <div className="grid grid-2">
        <section className="card stack">
          <h2 className="section-title">今日记录</h2>
          {record ? (
            <dl className="kv">
              <div><dt>喂食</dt><dd>{record.food_amount_g ?? 0} g</dd></div>
              <div><dt>饮水</dt><dd>{record.water_ml ?? 0} ml</dd></div>
              <div><dt>活动</dt><dd>{record.activity_minutes ?? 0} 分钟</dd></div>
              <div><dt>食欲</dt><dd>{record.appetite_score}</dd></div>
              <div><dt>精神</dt><dd>{record.energy_score}</dd></div>
              <div><dt>便便</dt><dd>{record.poop_status || "-"}</dd></div>
              <div><dt>心情</dt><dd>{record.mood || "-"}</dd></div>
              <div><dt>备注</dt><dd>{record.notes || "无"}</dd></div>
            </dl>
          ) : <div className="empty">今天还没有记录。</div>}
        </section>

        <section className="card stack">
          <h2 className="section-title">今日任务</h2>
          {dashboard.tasks.length === 0 ? <div className="empty">今天还没有任务。</div> : null}
          <ul className="list">
            {dashboard.tasks.slice(0, 4).map((task) => (
              <li key={task.id} className={`list-item ${task.is_completed ? "done" : ""}`}>
                <div className="row" style={{ justifyContent: "space-between" }}>
                  <div className="stack" style={{ flex: 1 }}>
                    <strong>{task.title}</strong>
                    <span className="small">{task.description || "无描述"}</span>
                  </div>
                  <span className="badge">{task.is_completed ? "已完成" : "未完成"}</span>
                </div>
              </li>
            ))}
          </ul>
          <Link className="button inline" href={`/pets/${petId}/tasks`}>去任务页</Link>
        </section>
      </div>
    </main>
  );
}
